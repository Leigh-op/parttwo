/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
 package parttwo;

import java.util.Scanner;
  

/**
 *
 * @author Student
 */
     
public class Parttwo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Message msgProcessor = new Message();

        System.out.println("=========================================");
        System.out.println("          Welcome to QuickChat.          ");
        System.out.println("=========================================");

        // Login Check
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        boolean isLoggedIn = true; 

        if (!isLoggedIn) {
            System.out.println("Login failed. Exiting application.");
            return;
        }

        System.out.println("Login successful!\n");

        boolean running = true;
        int totalMessagesSentCount = 0;

        while (running) {
            System.out.println("\n--- QuickChat Menu ---");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Select an option (1-3): ");

            String choiceInput = scanner.nextLine();

            if (choiceInput.equalsIgnoreCase("quit") || choiceInput.equals("3")) {
                System.out.println("Exiting QuickChat. Goodbye!");
                break;
            }

            int choice;
            try {
                choice = Integer.parseInt(choiceInput);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid menu number.");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.print("\nHow many messages would you like to enter? ");
                    int numMessages;
                    try {
                        numMessages = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid number. Returning to menu.");
                        break;
                    }

                    for (int i = 1; i <= numMessages; i++) {
                    System.out.println("\n--- Entering Message " + i + " of " + numMessages + " ---");

                        // Recipient Validation Loop
                        String recipient;
                        Message msgProcessor = new Message();
                      
                        while (true) {
                            System.out.print("Enter recipient cell number (max 10 chars, include country code like ): ");
                            recipient = scanner.nextLine();
                            
                            //Create an object instance of Message (or whatever class contains checkRecipientCell)

                             if (!msgProcessor.checkRecipientCell(recipient).equals("Valid number")) {
                                 System.out.println("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
                             } else { 
                                 System.out.println("Cell phone number successfully captured.");
                                 break;
                             }
                        }

                        // Message Length Validation Loop
                        String messageText;
                        while (true) {
                            System.out.print("Enter message text (max 250 characters): ");
                            messageText = scanner.nextLine();
                            if (msgProcessor.checkMessageLength(messageText)) {
                                System.out.println("Message sent.");
                                break;
                            } else {
                                int excess = messageText.length() - 250;
                                System.out.println("Please enter a message of less than 250 characters. (Exceeded by " + excess + " characters).");
                            }
                        }

                        // Auto-generate ID and Hash
                        String messageID = msgProcessor.generateMessageID();
                        String messageHash = msgProcessor.createMessageHash(messageID, i, messageText);

                        // Send options menu
                        System.out.println("\nChoose an action for this message:");
                        System.out.println("1) Send Message");
                        System.out.println("2) Discard Message");
                        System.out.println("3) Store Message to send later");
                        System.out.print("Enter choice (1-3): ");
                        
                        int actionChoice;
                        try {
                            actionChoice = Integer.parseInt(scanner.nextLine());
                        } catch (NumberFormatException e) {
                            actionChoice = 1; 
                        }

                        String actionResult = msgProcessor.processMessageOption(actionChoice);
                        System.out.println(actionResult);

                        if (actionChoice == 1) {
                            totalMessagesSentCount++;
                        }

                        // Display Details
                        System.out.println("\n=========================================");
                        System.out.println("         SAVED MESSAGE DETAILS           ");
                        System.out.println("=========================================");
                        System.out.println("Message ID  : " + messageID);
                        System.out.println("Message Hash: " + messageHash);
                        System.out.println("Recipient   : " + recipient);
                        System.out.println("Message     : " + messageText);
                        System.out.println("=========================================");
                    }

                    System.out.println("\nTotal messages successfully sent this session: " + totalMessagesSentCount);
                    break;

                case 2:
                    System.out.println("\nComing Soon.");
                    break;

                default:
                    System.out.println("Invalid option. Please choose 1, 2, or 3.");
                    break;
            }
        }
        scanner.close();
    }
}